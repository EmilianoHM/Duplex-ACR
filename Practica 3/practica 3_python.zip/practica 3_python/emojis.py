# Emojis Unicode
smiley = "\U0001F600"  # Cara sonriente con ojos sonrientes
heart = "\U00002764"   # Corazón rojo

# Imprimir emojis
print(smiley)
print(heart)
